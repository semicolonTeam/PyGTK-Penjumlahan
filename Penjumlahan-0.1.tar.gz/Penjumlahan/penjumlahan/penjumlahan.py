import pygtk
pygtk.require('2.0')
import gtk, sys

class Kalkulator():
    def kill(self, widget, event):
        print "Selamat tinggal .. :*"
        sys.exit(1)

    def hitung(self, widget):
        try:
            ang1 = self.in1.get_text()
            ang2 = self.in2.get_text()
            ang1 = int(ang1)
            ang2 = int(ang2)
            self.hasil.set_text(str(ang1+ang2))
            print "Hasilnya adalah", str(ang1+ang2)
        except(ValueError):
            print "Salah memasukkan angka"
            self.hasil.set_text("Salah memasukkan angka")

    def ulangi(self, widget):
        self.u+=1
        print self.u, "kali ulang"
        self.in1.set_text("")
        self.in2.set_text("")
        self.hasil.set_text(str(self.u) + " kali ulang")

    def __init__(self):
        # Var
        self.u = 0

        # Parent window
        self.win = gtk.Window(gtk.WINDOW_TOPLEVEL)
        self.win.set_position(gtk.WIN_POS_CENTER)
        self.win.set_resizable(False)
        self.win.set_title("Penjumlahan")
        self.win.set_icon_from_file("/usr/share/pixmaps/penjumlahan/logoKalk.svg")
        self.win.set_size_request(400, 160)
        self.win.connect("delete_event", self.kill)

        self.border = gtk.VBox(False)
        self.win.add(self.border)

        # space
        self.topMargin = gtk.Label()
        self.border.pack_start(self.topMargin, False, False, 0)
        self.topMargin.show()

        # Working Area
        self.borderWork = gtk.HBox(True)
        self.border.pack_start(self.borderWork, False, False, 0)
        self.borderWork.show()

        # Label
        self.inbox1 = gtk.VBox(True, 10)
        self.borderWork.pack_start(self.inbox1, False, False, 0)
        self.inbox1.show()

        # Label 1
        self.lin1 = gtk.Label("Angka pertama :")
        self.inbox1.pack_start(self.lin1, False, False, 0)
        self.lin1.show()

        self.lin2 = gtk.Label("Angka kedua   :")
        self.inbox1.pack_start(self.lin2, False, False, 0)
        self.lin2.show()

        # Input
        self.inbox2 = gtk.VBox(True, 10)
        self.borderWork.pack_start(self.inbox2, False, False, 10)
        self.inbox2.show()

        # Input 1
        self.in1 = gtk.Entry(10)
        self.in1.set_editable(True)
        self.in1.set_tooltip_text("Tempat untuk memasukkan angka \"PERTAMA\" Anda")
        self.inbox2.pack_start(self.in1, False, False, 0)
        self.in1.show()

        # Input 2
        self.in2 = gtk.Entry(10)
        self.in2.set_editable(True)
        self.in2.set_tooltip_text("Tempat untuk memasukkan angka \"KEDUA\" Anda")
        self.inbox2.pack_start(self.in2, False, False, 0)
        self.in2.show()

        # Tombol
        self.btnBox = gtk.VBox(True, 10)
        self.borderWork.pack_start(self.btnBox, False, False, 10)
        self.btnBox.show()

        # Tombol Hitung
        self.btnHtgBox = gtk.HBox()
        self.btnHtgBox.show()

        self.imgHitung = gtk.Image()
        self.imgHitung.set_from_file("/usr/share/penjumlahan/logoHtg.svg")
        self.imgHitung.show()

        self.lHtg = gtk.Label(" HITUNG")
        self.lHtg.show()

        self.btnHtgBox.pack_start(self.imgHitung, False, False, 0)
        self.btnHtgBox.pack_start(self.lHtg, False, False, 0)

        self.btnHitung = gtk.Button()
        self.btnHitung.set_tooltip_text("Hitung angka yang Anda masukkan (penjumlahan)")
        self.btnHitung.connect("clicked", self.hitung)
        self.btnHitung.add(self.btnHtgBox)
        self.btnBox.pack_start(self.btnHitung, False, False, 0)
        self.btnHitung.show()

        # Tombol Ulangi
        self.btnHtgBox = gtk.HBox()
        self.btnHtgBox.show()

        self.imgHitung = gtk.Image()
        self.imgHitung.set_from_file("/usr/share/penjumlahan/logoUlangi.svg")
        self.imgHitung.show()

        self.lHtg = gtk.Label(" ULANGI")
        self.lHtg.show()

        self.btnHtgBox.pack_start(self.imgHitung, False, False, 0)
        self.btnHtgBox.pack_start(self.lHtg, False, False, 0)

        self.btnHitung = gtk.Button()
        self.btnHitung.set_tooltip_text("Bersihkan semua masukan")
        self.btnHitung.add(self.btnHtgBox)
        self.btnHitung.connect("clicked", self.ulangi)
        self.btnBox.pack_start(self.btnHitung, False, False, 0)
        self.btnHitung.show()

        # Border Hasil
        self.borderHasil = gtk.VBox(False)
        self.border.pack_start(self.borderHasil, False, False, 0)
        self.borderHasil.show()

        self.space = gtk.Label()
        self.borderHasil.pack_start(self.space, False, False, 0)
        self.space.show()

        self.hasil = gtk.Label("00")
        self.hasil.set_tooltip_text("Hasil perhitungan yang Anda lakukan")
        self.borderHasil.pack_start(self.hasil, False, False, 10)
        self.hasil.show()

        self.author = gtk.Label("Created by Hadi Hidayat Hammurabi")
        self.borderHasil.pack_start(self.author, False, False, 0)
        self.author.show()

        self.border.show()
        self.win.show()

Kalkulator()
gtk.main()
